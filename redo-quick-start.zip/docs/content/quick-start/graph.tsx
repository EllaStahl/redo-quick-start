import React from 'react';
// import { RelationsGraph } from '@teambit/graph.relations-graph';

export function WikiGraph() {
  return (
    <div style={{ width: '100%', height: 500 }}>
      {/* <RelationsGraph
        scopes={[{ id: 'teambit.wiki', isOpen: true }, { id: 'teambit.design' }, { id: 'teambit.docs' }]}
      /> */}
    </div>
  );
}
