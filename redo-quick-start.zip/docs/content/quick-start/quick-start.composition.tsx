import React from 'react';
import { QuickStart } from './index';

export const BasicQuickStart = () => <QuickStart />;
