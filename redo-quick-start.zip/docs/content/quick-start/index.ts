import { DocsQuickStart as QuickStart } from './quick-start';

export { QuickStart };
export default QuickStart;
